// To parse this JSON data, do
//
//     final salaryDetailModel = salaryDetailModelFromJson(jsonString);

import 'dart:convert';

SalaryDetailModel salaryDetailModelFromJson(String str) => SalaryDetailModel.fromJson(json.decode(str));

String salaryDetailModelToJson(SalaryDetailModel data) => json.encode(data.toJson());

class SalaryDetailModel {
  SalaryDetailModel({
    this.status,
    this.msg,
    this.data,
  });

  bool status;
  String msg;
  List<Datum> data;

  factory SalaryDetailModel.fromJson(Map<String, dynamic> json) => SalaryDetailModel(
    status: json["status"] == null ? null : json["status"],
    msg: json["msg"] == null ? null : json["msg"],
    data: json["data"] == null ? null : List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status == null ? null : status,
    "msg": msg == null ? null : msg,
    "data": data == null ? null : List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.name,
    this.designation,
    this.joiningDate,
    this.grossSalary,
    this.perDaySalary,
    this.totalWorkingDays,
    this.number,
    this.totalCredit,
    this.credit,
    this.leave,
    this.deduct,
    this.totalDeduct,
    this.netSalary,
  });

  String name;
  String designation;
  String joiningDate;
  String grossSalary;
  int perDaySalary;
  String totalWorkingDays;
  String number;
  int totalCredit;
  List<Credit> credit;
  int leave;
  List<Credit> deduct;
  int totalDeduct;
  int netSalary;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    name: json["name"] == null ? null : json["name"],
    designation: json["designation"] == null ? null : json["designation"],
    joiningDate: json["joining_date"] == null ? null : json["joining_date"],
    grossSalary: json["gross_salary"] == null ? null : json["gross_salary"],
    perDaySalary: json["per_day_salary"] == null ? null : json["per_day_salary"],
    totalWorkingDays: json["total_working_days"] == null ? null : json["total_working_days"],
    number: json["number"] == null ? null : json["number"],
    totalCredit: json["total_credit"] == null ? null : json["total_credit"],
    credit: json["credit"] == null ? null : List<Credit>.from(json["credit"].map((x) => Credit.fromJson(x))),
    leave: json["leave"] == null ? null : json["leave"],
    deduct: json["deduct"] == null ? null : List<Credit>.from(json["deduct"].map((x) => Credit.fromJson(x))),
    totalDeduct: json["total_deduct"] == null ? null : json["total_deduct"],
    netSalary: json["net_salary"] == null ? null : json["net_salary"],
  );

  Map<String, dynamic> toJson() => {
    "name": name == null ? null : name,
    "designation": designation == null ? null : designation,
    "joining_date": joiningDate == null ? null : joiningDate,
    "gross_salary": grossSalary == null ? null : grossSalary,
    "per_day_salary": perDaySalary == null ? null : perDaySalary,
    "total_working_days": totalWorkingDays == null ? null : totalWorkingDays,
    "number": number == null ? null : number,
    "total_credit": totalCredit == null ? null : totalCredit,
    "credit": credit == null ? null : List<dynamic>.from(credit.map((x) => x.toJson())),
    "leave": leave == null ? null : leave,
    "deduct": deduct == null ? null : List<dynamic>.from(deduct.map((x) => x.toJson())),
    "total_deduct": totalDeduct == null ? null : totalDeduct,
    "net_salary": netSalary == null ? null : netSalary,
  };
}

class Credit {
  Credit({
    this.name,
    this.value,
  });

  String name;
  int value;

  factory Credit.fromJson(Map<String, dynamic> json) => Credit(
    name: json["name"] == null ? null : json["name"],
    value: json["value"] == null ? null : json["value"],
  );

  Map<String, dynamic> toJson() => {
    "name": name == null ? null : name,
    "value": value == null ? null : value,
  };
}
