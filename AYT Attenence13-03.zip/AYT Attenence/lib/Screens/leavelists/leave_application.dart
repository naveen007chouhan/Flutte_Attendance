import 'package:flutter/material.dart';
import 'package:grouped_buttons/grouped_buttons.dart';
import 'package:http/http.dart' as http;


class LeaveApplication extends StatefulWidget {
  @override
  LeaveApplicationWidgetState createState() => LeaveApplicationWidgetState();
}

class LeaveApplicationWidgetState extends State<LeaveApplication>
    with SingleTickerProviderStateMixin {

  List<String> leaveType = [
    "Daily Meals",
    "Petrol ",
    "Other wages",
  ];

  List<String> leaveKeys = [
    "ml",
    "al",
    "cl",
  ];

  void main() async {
    var headers = {
      'x-api-key': 'NODN2D0I7W4V8I2K',
      'Content-Type': 'application/json',
      'Cookie': 'ci_session=1066fe58e5bb9fc1bac4a00fba3df3fd66ce215c'
    };
    var request = http.Request('POST', Uri.parse('http://adiyogitechnosoft.com/attendance_dev/api/leave'));
    request.body = '''{"employee_id": "NODN2D0I7W4V8I2K","leave_type_id": "1","from_date": "5-3-2021","to_date": "5-3-2021",\n            "reason": "test",\n            "half_day": "0"\n        }''';
    request.headers.addAll(headers);
    request.followRedirects = false;

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      print(await response.stream.bytesToString());
    }
    else {
      print(response.reasonPhrase);
    }

  }

  int leaveIndex = -1;
  List<Widget> list = null;

  String _errorMessage;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          textTheme: TextTheme(
              body1: TextStyle(
                  color: Colors.black87,
                  fontFamily: "poppins-medium",
                  fontSize: 15,
                  letterSpacing: 0.5,
                  fontWeight: FontWeight.w400),
              button: TextStyle(
                  color: Colors.black87,
                  fontFamily: "poppins-medium",
                  fontSize: 18,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w900))),
      home: Scaffold(
          resizeToAvoidBottomPadding: true,
          appBar: AppBar(
            title: Text('Leave Application'),
            backgroundColor: Colors.blue[1000],
            leading: new IconButton(
              icon: new Icon(Icons.arrow_back_ios),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
          body: SingleChildScrollView(
              child: Container(
                  padding: const EdgeInsets.symmetric(
                      vertical: 16.0, horizontal: 16.0),
                  child: Builder(
                      builder: (context) => Form(
                          //key: _formKey,
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Center(
                                  child: Text(
                                    "Available Leaves",
                                  ),
                                ),
                                Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: list == null
                                        ? LinearProgressIndicator()
                                        : Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                      children: list,
                                    )),
                                Text("Your Manager"),
                                Container(
                                  padding:
                                  const EdgeInsets.fromLTRB(0, 5, 0, 20),
                                  child: TextFormField(
                                      readOnly: true,
                                      decoration: InputDecoration(

                                        border: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              color: Colors.redAccent,
                                              width: 5.0),
                                        ),
                                      ),
                                      onTap: () {
                                        _showDialog(context);
                                      }),
                                ),
                                Text("Today's Date"),
                                Container(
                                  padding:
                                  const EdgeInsets.fromLTRB(0, 5, 0, 20),
                                  child: TextField(
                                    readOnly: true,
                                    enabled: false,
                                    decoration: InputDecoration(

                                      labelStyle:
                                      TextStyle(color: Colors.black54),
                                      disabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: Colors.black45, width: 1.0),
                                      ),
                                    ),
                                    onTap: () {},
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    Text('From'),
                                    Container(
                                        padding: const EdgeInsets.fromLTRB(
                                            0, 5, 0, 20),
                                        child: RaisedButton(
                                          color: Colors.white,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(5.0)),
                                          elevation: 4.0,
                                          onPressed: () {

                                          },
                                          child: Container(
                                            alignment: Alignment.center,
                                            height: 50.0,
                                            child: Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .spaceBetween,
                                              children: <Widget>[
                                                Row(
                                                  children: <Widget>[
                                                    Container(
                                                      child: Row(
                                                        children: <Widget>[
                                                          Text(
                                                            "",
                                                            style: TextStyle(
                                                              color: Colors.blue,
                                                              fontSize: 16.0,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    )
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        )),
                                    Text('To'),
                                    Container(
                                        padding: const EdgeInsets.fromLTRB(
                                            0, 5, 0, 20),
                                        child: RaisedButton(
                                          color: Colors.white,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(5.0)),
                                          elevation: 4.0,
                                          onPressed: () {

                                          },
                                          child: Container(
                                            alignment: Alignment.center,
                                            height: 50.0,
                                            child: Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .spaceBetween,
                                              children: <Widget>[
                                                Row(
                                                  children: <Widget>[
                                                    Container(
                                                      child: Row(
                                                        children: <Widget>[
                                                          Text(
                                                            "",
                                                            style: TextStyle(
                                                                color: Colors.blue,
                                                                fontSize: 16.0),
                                                          ),
                                                        ],
                                                      ),
                                                    )
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        )),
                                  ],
                                ),
                                Container(
                                  child: Text(
                                      'Number of days on leave: '),
                                ),
                                Container(
                                  padding:
                                  const EdgeInsets.fromLTRB(0, 20, 0, 20),
                                  child: Text('Type of leave'),
                                ),
                                CheckboxGroup(
                                  labels: <String>[
                                    leaveType[0],
                                    leaveType[1],
                                    leaveType[2],
                                  ],
                                  //checked: _checked,
                                  activeColor: Colors.red,
                                  onChange: (bool isChecked, String label,
                                      int index) {
                                    print(
                                        "isChecked: $isChecked   label: $label  index: $index");
                                    leaveIndex = index;
                                  },
                                  onSelected: (List selected) => setState(() {
                                    //isSelected = true;
                                    if (selected.length > 1) {
                                      selected.removeAt(0);
                                      print(
                                          'selected length  ${selected.length}');
                                    } else {
                                      print("only one");
                                    }
                                    //_checked = selected;
                                  }),
                                ),
                                TextField(
                                  autofocus: false,
                                  //controller: emailController,
                                  //onSubmitted: _giveData(emailController),
                                  decoration: new InputDecoration(
                                    labelText:
                                    "Message for Management (Optional)",
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                      BorderSide(color: Colors.black54),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                      BorderSide(color: Colors.black54),
                                    ),
                                  ),
                                ),
                                Container(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 16.0, horizontal: 16.0),
                                    child: RaisedButton(
                                        color: Colors.blue[2000],
                                        hoverColor: Colors.blue[1000],
                                        hoverElevation: 40.0,
                                        onPressed: () {}
                                    )
                                ),
                              ])
                          )
                      )
                  )
              )
          ),
    );
  }

  void giveData(TextEditingController controller) {
    //msg = controller.text;
  }

  void _showDialog(context) {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: Center(child: Text("Manager Details")),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[

            ],
          ),
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
            new FlatButton(
              child: new Text("Close"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

String getDoubleDigit(String value) {
  if (value.length >= 2) return value;
  return "0" + value;
}

String getFormattedDate(DateTime day) {
  String formattedDate = getDoubleDigit(day.day.toString()) +
      "-" +
      getDoubleDigit(day.month.toString()) +
      "-" +
      getDoubleDigit(day.year.toString());
  return formattedDate;
}
