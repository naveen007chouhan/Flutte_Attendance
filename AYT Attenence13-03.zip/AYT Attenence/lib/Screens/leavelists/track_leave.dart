import 'dart:convert';

import 'package:AYT_Attendence/API/api.dart';
import 'package:AYT_Attendence/Screens/leavelists/leave_application.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:AYT_Attendence/Screens/leavelists/model/TrackLeaveModel.dart';



class MyTrackLeave extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyTrackLeave> {
  String unique_id2;

  @override
  void initState(){
    // TODO: implement initState
    super.initState();
    getData();
    loadStudent();
  }

  getData()async{
    SharedPreferences sharedPreferences=await SharedPreferences.getInstance();
    setState(() {
      unique_id2=sharedPreferences.getString("unique_id");
    });
  }

  Future<TrackLeaveModel> loadStudent() async {
    await wait(5);
    var endpointUrl =
        All_API().baseurl + All_API().api_apply_leave + unique_id2;
    print("NotificationUrl--> " + endpointUrl);
    try {
      var response = await http.get(endpointUrl, headers: {
        All_API().key: All_API().keyvalue,
      });
      print("TrackLeaveResponse--> " + response.body);
      var jasonDataNotification = jsonDecode(response.body);
      return TrackLeaveModel.fromJson(jasonDataNotification);

    } catch (Exception) {
      return Exception;
    }
  }

  Future wait(int seconds) {
    return new Future.delayed(Duration(seconds: seconds), () => {});
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double categoryHeight = size.height*0.30;
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: 8,
          backgroundColor: Colors.blue[1000],
          title: Container(
            margin: EdgeInsets.only(top: 0,bottom: 0,left: 40,right: 0),
            child: Text('Track Expenses',style: TextStyle(color: Colors.blue[2000]),),
          ),
        ),
        body: Container(
          height: size.height,
          child: Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  Container(
                    child: Text(
                      'Leave Apply',style: TextStyle(
                        fontSize: 15,fontStyle: FontStyle.normal
                    ),
                    ),
                  ),
                  Container(
                    child: Center(child:
                    RaisedButton(
                      child: Row(
                        children: [
                          Icon(Icons.add),
                          Text('ADD')
                        ],
                      ),
                      color: Colors.blue[1000],
                      textColor: Colors.white,
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                          side: BorderSide(color: Colors.blue[1000])
                      ),
                      padding: EdgeInsets.fromLTRB(30, 10, 30, 10),
                      splashColor: Colors.blue[2000],
                      onPressed: () {
                        //onpressed gets called when the button is tapped.
                        print("FlatButton tapped");
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LeaveApplication()));
                      },
                    ),
                    ),
                  )
                ],
              ),
              FutureBuilder<TrackLeaveModel>(
                  future: loadStudent(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return ListView.builder(
                          itemCount: snapshot.data.data.length,
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            var notificationlist = snapshot.data.data[index];
                            var str=notificationlist.date.toString();
                            var Strdate=str.split(" ");
                            var date = Strdate[0].trim();
                            var time = Strdate[1].trim();
                            return Card(
                                elevation: 8.0,
                                margin: new EdgeInsets.symmetric(
                                    horizontal: 10.0, vertical: 6.0),
                                child: Column(
                                  children: [
                                    Text(notificationlist.name,
                                        style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
                                    Text("Date-: $date"+" Time-: $time"),
                                  ],
                                )
                            );
                          });
                    } else
                      //return Center(child: CircularProgressIndicator());
                      return ListView.builder(
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return Card(
                                elevation: 8.0,
                                margin: new EdgeInsets.symmetric(
                                    horizontal: 10.0, vertical: 6.0),
                                child: Column(
                                  children: [
                                    Text("Leave Name",
                                        style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
                                    Text("Date-: "+" Time-: "),
                                  ],
                                )
                            );
                          });
                  })
            ],
          ),
        ),
      ),
    );
  }
}