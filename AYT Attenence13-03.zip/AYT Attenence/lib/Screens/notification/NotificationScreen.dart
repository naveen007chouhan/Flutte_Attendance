import 'dart:convert';

import 'package:AYT_Attendence/API/api.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';
import 'package:http/http.dart' as http;

import 'NotificationModel.dart';

class NotificationScreen extends StatefulWidget {
  @override
  NotificationScreenState createState() => NotificationScreenState();
}

class NotificationScreenState extends State<NotificationScreen> {
  var userid = "NODS5X5N5V2H2Z";
  Future<NotificationModel> notification() async {
    var endpointUrl =
        All_API().baseurl + All_API().api_notification + userid;
    print("NotificationUrl--> " + endpointUrl);
    // Map<String, String>  queryParameter={
    //   '':'',
    // };
    // String queryString = Uri(queryParameters: queryParameter).query;
    // var requestUrl = endpointUrl + '?' + queryString;
    // print(requestUrl);
    try {
      var response = await http.get(endpointUrl, headers: {
        All_API().key: All_API().keyvalue,
      });
      print("Notificationresponse--> " + response.body);
      if (response.statusCode == 200) {
        var jasonDataNotification = jsonDecode(response.body);
        return NotificationModel.fromJson(jasonDataNotification);
      }
    } catch (Exception) {
      return Exception;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<NotificationModel>(
        future: notification(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
                itemCount: snapshot.data.data.length,
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  var notificationlist = snapshot.data.data[index];
                  return Card(
                    elevation: 8.0,
                    margin: new EdgeInsets.symmetric(
                        horizontal: 10.0, vertical: 6.0),
                    child: Container(
                      decoration: BoxDecoration(

                          color: Colors.blue[1000],
                          // color: Color.fromRGBO(64, 75, 96, .9),
                          borderRadius:
                          BorderRadius.all(Radius.circular(10.0))),
                      child: Column(
                        children: [
                          Icon(Icons.notification_important_rounded, color: Colors.amber),
                          Text(notificationlist.title, style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
                          Text(notificationlist.message),
                        ],
                      ),
                    ),
                  );
                });
          } else
            return Center(child: CircularProgressIndicator());
        });
  }
}