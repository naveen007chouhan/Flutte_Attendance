import 'dart:convert';
import 'package:AYT_Attendence/API/api.dart';
import 'package:AYT_Attendence/model/LeaveModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;


class leaveFeed extends StatefulWidget{
  leaveFeed({this.unique_id});
  final String unique_id;
  @override
  _leaveFeedState createState() => _leaveFeedState(unique_id2:unique_id);
}

class _leaveFeedState extends State<leaveFeed> {
  _leaveFeedState({this.unique_id2});

  final String unique_id2;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  Future<LeaveModelData> loadStudent() async {
    await wait(5);
    var endpointUrl = All_API().baseurl+All_API().api_leave_type + unique_id2;
    Map<String, String> headers = {
      All_API().key: All_API().keyvalue,
    };

    var response = await http.get(endpointUrl,headers: headers);

    Map jasonData = jsonDecode(response.body);
    print('Leaves : '+jasonData.toString());
    return new LeaveModelData.fromJson(jasonData);
  }

  Future wait(int seconds) {
    return new Future.delayed(Duration(seconds: seconds), () => {});
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<LeaveModelData>(
      future: loadStudent(),
      builder: (context,snapshot){
        if(snapshot.hasData){
          return ListView.builder(
              itemCount: snapshot.data.data.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index){
                var article = snapshot.data.data[index];
                return Card(
                  elevation: 10,
                  child: Container(
                    margin: EdgeInsets.all(5),
                    child: Row(
                      children: [
                        Row(
                          children: [
                            Column(
                              children: [
                                Container(
                                  width: 50,
                                  height: 70,
                                  alignment: Alignment.center,
                                  margin: const EdgeInsets.all(3.0),
                                  child: Text(article.totalUsed.toString(),style: TextStyle(fontSize: 30,color: Colors.red,fontWeight: FontWeight.bold),),
                                ),
                                Container(
                                  width: 50,
                                  alignment: Alignment.bottomCenter,
                                  child: Text("USED",style: TextStyle(fontSize: 10,color: Colors.black),),
                                ),
                              ],
                            ),
                            Column(
                              children: [
                                Container(
                                  width: 100,
                                  height: 50,
                                  alignment: Alignment.center,
                                  child: Text(article.leaveType,style: TextStyle(fontSize: 18,color: Colors.black),),
                                ),
                                Container(
                                  width: 70,
                                  height: 45,
                                  alignment: Alignment.center,
                                  child: Column(
                                    children: [
                                      Center(child: Text(article.totalAllowd,style: TextStyle(fontSize: 25,color: Colors.black),)),
                                      Center(child: Text("ALLOWED",style: TextStyle(fontSize: 10,color: Colors.black),))
                                    ],
                                  ),
                                ),
                              ],
                            )
                          ],
                        )
                        ,
                      ],
                    ),
                  ),
                );
              }
          );
        }
        else
          return Center(child: CircularProgressIndicator());
      },
    );
  }
}