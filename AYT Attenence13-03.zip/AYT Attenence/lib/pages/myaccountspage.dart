import 'dart:convert';

import 'package:AYT_Attendence/API/api.dart';
import 'package:AYT_Attendence/model/DepartmentModel.dart';
import 'package:AYT_Attendence/model/DesignationModel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';



class MyAccountsPage extends StatefulWidget {
  @override
  _MyAccountsPageState createState() => _MyAccountsPageState();
}

class _MyAccountsPageState extends State<MyAccountsPage> {
  String baseUrl="http://adiyogitechnosoft.com/attendance_dev/uploads/employee/";

  String name;
  String uniqId ;
  String user_unique_id ;
  String email ;
  String phone ;
  String dob ;
  String joining_date ;
  String department_id ;
  String designation_id ;
  String image ;


  @override
  void initState(){
    // TODO: implement initState
    super.initState();
    getData();
  }
  Future<Departmentmodel> department_user_id() async {
    await wait(5);
    var endpointUrl = All_API().baseurl+All_API().api_department + department_id;
    Map<String, String> headers = {
      All_API().key: All_API().keyvalue,
    };

    var response = await http.get(endpointUrl,headers: headers);

    Map jasonData = jsonDecode(response.body);
    print('Department Data : '+jasonData.toString());
    return new Departmentmodel.fromJson(jasonData);
  }

  Future wait(int seconds) {
    return new Future.delayed(Duration(seconds: seconds), () => {});
  }

  Future<Designationmodel> designation_user_id() async {
    await wait(5);
    var endpointUrl = All_API().baseurl+All_API().api_designation + designation_id;
    Map<String, String> headers = {
      All_API().key: All_API().keyvalue,
    };

    var response = await http.get(endpointUrl,headers:headers );

    Map jasonData = jsonDecode(response.body);
    print('Designation Data : '+jasonData.toString());
    return new Designationmodel.fromJson(jasonData);
  }

  getData()async{
    SharedPreferences sharedPreferences=await SharedPreferences.getInstance();
    setState(() {
      name=sharedPreferences.getString("name");
      uniqId=sharedPreferences.getString("unique_id");
      user_unique_id=sharedPreferences.getString("user_unique_id");
      email=sharedPreferences.getString("email");
      phone=sharedPreferences.getString("phone");
      dob=sharedPreferences.getString("dob");
      joining_date=sharedPreferences.getString("joining_date");
      department_id=sharedPreferences.getString("department_id");
      designation_id=sharedPreferences.getString("designation_id");
      image=sharedPreferences.getString("image");
    });
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: Stack(
        children: <Widget>[
          ClipPath(
            child: Container(color: Colors.blue[1000]),
            clipper: getClipper(),
          ),
          Positioned(
              width: 350.0,
              top: MediaQuery.of(context).size.height / 5,
              child: Column(
                children: <Widget>[
                  Container(
                      margin: EdgeInsets.only(top: 0,bottom: 0,left: 60,right: 0),
                      transform: Matrix4.translationValues(0.0, -40.0, 20.0),
                      width: 150.0,
                      height: 150.0,
                      decoration: BoxDecoration(
                          color: Colors.red,
                          image: DecorationImage(
                              image: NetworkImage(
                                  baseUrl+image),
                              fit: BoxFit.cover),
                          borderRadius: BorderRadius.all(Radius.circular(100.0)),
                          boxShadow: [
                            BoxShadow(blurRadius: 7.0, color: Colors.black)
                          ])),
                  Container(
                    transform: Matrix4.translationValues(30.0, -20.0, 20.0),
                    height: 50.0,
                    child: Text(
                      name,
                      style: TextStyle(
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Montserrat'),
                    ),
                  ),
                  Container(
                    transform: Matrix4.translationValues(30.0, -20.0, 20.0),
                    height: 30.0,
                    child: FutureBuilder<Designationmodel>(
                      future: designation_user_id(),
                      builder: (context,snapshot){
                        if(snapshot.hasData){
                          return Text(
                            snapshot.data.data.name,
                            style: TextStyle(
                                fontSize: 17.0,
                                fontStyle: FontStyle.italic,
                                fontFamily: 'Montserrat'),
                          );
                        }
                        else
                          return Center(child: CircularProgressIndicator());
                      },
                    ),
                  ),
                  Container(
                    width: 300,
                    height: 60,
                    transform: Matrix4.translationValues(-20.0, -20.0, 20.0),
                    child: Card(
                      elevation: 15,
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(0), topRight: Radius.circular(30),
                              bottomRight: Radius.circular(30),bottomLeft: Radius.circular(0))),
                      child: Container(
                        transform: Matrix4.translationValues(20.0, 0.0, 20.0),
                        child: Row(
                          children: [
                            Container(
                              width: 100,
                              child:Text('Email :'),
                            ),
                            Container(
                              width: 150,
                              child:Text(email,),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 300,
                    height: 60,
                    transform: Matrix4.translationValues(-20.0, -20.0, 20.0),
                    child: Card(
                      elevation: 15,
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(0), topRight: Radius.circular(30),
                              bottomRight: Radius.circular(30),bottomLeft: Radius.circular(0))),
                      child: Container(
                        transform: Matrix4.translationValues(20.0, 0.0, 20.0),
                        child: Row(
                          children: [
                            Container(
                              width: 100,
                              child:Text('Employee ID :'),
                            ),
                            Container(
                              width: 150,
                              child:Text(user_unique_id),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 300,
                    height: 60,
                    transform: Matrix4.translationValues(-20.0, -20.0, 20.0),
                    child: Card(
                      elevation: 15,
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(0), topRight: Radius.circular(30),
                              bottomRight: Radius.circular(30),bottomLeft: Radius.circular(0))),
                      child: Container(
                        transform: Matrix4.translationValues(20.0, 0.0, 20.0),
                        child: Row(
                          children: [
                            Container(
                              width: 100,
                              child:Text('Mobile No. :'),
                            ),
                            Container(
                              width: 150,
                              child:Text(phone,),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 300,
                    height: 60,
                    transform: Matrix4.translationValues(-20.0, -20.0, 20.0),
                    child: Card(
                      elevation: 15,
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(0), topRight: Radius.circular(30),
                              bottomRight: Radius.circular(30),bottomLeft: Radius.circular(0))),
                      child: Container(
                        transform: Matrix4.translationValues(20.0, 0.0, 20.0),
                        child: Row(
                          children: [
                            Container(
                              width: 100,
                              child:Text('Date of Birth :'),
                            ),
                            Container(
                              width: 150,
                              child:Text(dob,),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  FutureBuilder<Departmentmodel>(
                    future: department_user_id(),
                    builder: (context,snapshot){
                      if(snapshot.hasData){
                        return Container(
                          width: 300,
                          height: 60,
                          transform: Matrix4.translationValues(-20.0, -20.0, 20.0),
                          child: Card(
                            elevation: 15,
                            color: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(topLeft: Radius.circular(0), topRight: Radius.circular(30),
                                    bottomRight: Radius.circular(30),bottomLeft: Radius.circular(0))),
                            child: Container(
                              transform: Matrix4.translationValues(20.0, 0.0, 20.0),
                              child: Row(
                                children: [
                                  Container(
                                    width: 100,
                                    child:Text('Department :'),
                                  ),
                                  Container(
                                    width: 150,
                                    child: Text(snapshot.data.data.name),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }
                      else
                        return Center(child: CircularProgressIndicator());
                    },
                  ),
                  Container(
                    width: 300,
                    height: 60,
                    transform: Matrix4.translationValues(-20.0, -20.0, 20.0),
                    child: Card(
                      elevation: 15,
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(0), topRight: Radius.circular(30),
                              bottomRight: Radius.circular(30),bottomLeft: Radius.circular(0))),
                      child: Container(
                        transform: Matrix4.translationValues(20.0, 0.0, 20.0),
                        child: Row(
                          children: [
                            Container(
                              width: 100,
                              child:Text('Joining Date :'),
                            ),
                            Container(
                              child: Text(joining_date,),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 200),
                  Container(
                    height: 70,
                    width: 400,
                    transform: Matrix4.translationValues(150.0, -25.0, 20.0),
                    child: Card(
                      elevation: 20,
                      color: Colors.blue[2000],
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(50), topRight: Radius.circular(0),
                              bottomRight: Radius.circular(0),bottomLeft: Radius.circular(50))),
                      child: Container(
                        transform: Matrix4.translationValues(30.0, 0.0, 20.0),
                        alignment: Alignment.centerLeft,
                        child: Text('UPDATE PROFILE',style: TextStyle(color: Colors.blue[1000],fontSize: 20),),
                      ),
                    ),
                  ),
                ],
              ))
        ],
      ),
    );
  }
}

class getClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = new Path();

    path.lineTo(0.0, size.height / 2.5);
    path.lineTo(size.width + 125, 0.0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return true;
  }
}
