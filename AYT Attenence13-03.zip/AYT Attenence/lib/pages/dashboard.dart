import 'package:AYT_Attendence/sidebar/image_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'birthdayFeed.dart';
import 'checkIN_OUT.dart';
import 'leaveFeed.dart';
import 'newsFeeds.dart';


class Dashboard extends StatefulWidget {

  @override
  State<StatefulWidget> createState() {
    return _DashboardState();
  }
}

class _DashboardState extends State<Dashboard> {
  String name;
  String uniqId;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData()async{
    SharedPreferences preferences=await SharedPreferences.getInstance();
    setState(() {
      name=preferences.getString("name");
      uniqId=preferences.getString("unique_id");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: MediaQuery
              .of(context)
              .size
              .height,
          child: new Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              new Padding(
                padding: const EdgeInsets.all(0),
                //child: ImageSlider(),
              ),
              new Padding(
                padding: const EdgeInsets.all(12.0),
                child: new Center(

                  child: Text(name,
                    style: TextStyle(
                        fontSize: 20, fontStyle: FontStyle.normal,
                        color: Colors.black),),
                ),
              ),
              new Expanded(
                flex: 1,
                child: RefreshIndicator(
                  onRefresh: _refreshLocalGallery,
                  child: new SingleChildScrollView(
                    physics: AlwaysScrollableScrollPhysics(),
                    scrollDirection: Axis.vertical,
                    child: Column(
                      children: [
                        Container(
                          child: SizedBox(
                            height: 120,
                            child: new leaveFeed(unique_id: uniqId),
                          ),
                        ),
                        Container(
                          child: SizedBox(
                            height: 150,
                            child: checkIN_OUT(),
                          ),
                        ),
                        SizedBox(
                          height: 20,
                          child: new Text('Happy Birthday',
                            style: TextStyle(fontSize: 15,
                                color: Colors.blue[1000]),
                          ),),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: SizedBox(
                              height: 250,
                              child: birthdayFeed()
                          ),
                        ),
                        Row(
                          children: [
                            SizedBox(
                              height: 20,
                              child: new Text('News Feeds',
                                style: TextStyle(
                                    fontSize: 15, color: Colors.blue[1000]),
                              ),),
                            SizedBox(
                              height: 20,
                              child: Icon(Icons.remove_red_eye),
                            ),
                          ],
                        ),

                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: SizedBox(
                              height: 100,
                              child: newsFeeds()
                          ),
                        ),
                      ],

                    ),
                  ),
                ),
              ),
            ],
          ),
        )
    );
  }
  Future<Null> _refreshLocalGallery() async{
    print('refreshing stocks...');
  }
}
