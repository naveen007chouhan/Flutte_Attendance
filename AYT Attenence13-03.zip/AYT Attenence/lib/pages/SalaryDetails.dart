import 'dart:convert';

import 'package:AYT_Attendence/API/api.dart';
import 'package:AYT_Attendence/model/GeneralLeaveModel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SalaryDetails extends StatelessWidget{

  Future<GeneralLeaveModel> loadStudent() async {
    await wait(5);
    var endpointUrl = All_API().baseurl+All_API().api_general_leaves;
    Map<String, String> headers = {
      All_API().key: All_API().keyvalue,
    };
    var response = await http.get(endpointUrl,headers: headers);
    var jasonData = jsonDecode(response.body);
    print('General : '+jasonData.toString());
    return GeneralLeaveModel.fromJson(jasonData);
  }

  Future wait(int seconds) {
    return new Future.delayed(Duration(seconds: seconds), () => {});
  }

  @override
  Widget build(BuildContext context) {
    MediaQueryData mediaQuery = MediaQuery.of(context);
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Container(
          child: Text(
            'General Leave', style: TextStyle(color: Colors.blue[2000]),),
        ),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.blue[1000],
      ),
      body: Column(
        children: [
          Card(
            elevation: 10,
            child: Column(
              children: [
                Divider(
                  height: 1,
                  color: Colors.deepOrange,
                ),
                Text("Adiyogi"),
                Divider(
                  height: 1,
                  color: Colors.deepOrange,
                ),
                Row(
                  children: [
                    Card(
                      child: Container(
                        height: 100,
                        width: mediaQuery.size.width * 0.47,
                        child: Column(
                          children: [
                            Text("name"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("designation"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("jaoining date"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("current ctc"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: Colors.deepOrange,
                    ),
                    Card(
                      child: Container(
                        height: 100,
                        width: mediaQuery.size.width * 0.47,
                        child: Column(
                          children: [
                            Text("name"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("designation"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("jaoining date"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("current ctc"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
          Card(
            elevation: 10,
            child: Column(
              children: [
                Divider(
                  height: 1,
                  color: Colors.deepOrange,
                ),
                Text("Salary Details"),
                Divider(
                  height: 1,
                  color: Colors.deepOrange,
                ),
                Row(
                  children: [
                    Divider(
                      height: 1,
                      color: Colors.deepOrange,
                    ),
                    Card(
                      child: Container(
                        height: 100,
                        width: mediaQuery.size.width * 0.47,
                        child: Column(
                          children: [
                            Text("Cross Salary"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("Total Working Days"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("Leaves"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("Pay Rate(Per Day)"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: Colors.deepOrange,
                    ),
                    Card(
                      child: Container(
                        height: 100,
                        width: mediaQuery.size.width * 0.47,
                        child: Column(
                          children: [
                            Text("name"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("designation"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("jaoining date"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                            Text("current ctc"),
                            Divider(
                              height: 1,
                              color: Colors.deepOrange,
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
          Card(
            elevation: 10,
            child: Row(
              children: [
                Card(
                  elevation: 10,
                  child: Container(
                    height: 100,
                    width: mediaQuery.size.width * 0.47,
                    child: Column(
                      children: [
                        Text("Credit"),
                        Divider(
                          height: 1,
                          color: Colors.deepOrange,
                        ),
                        Row(
                          children: [
                            Column(
                              children: [
                                Divider(
                                  height: 1,
                                  color: Colors.deepOrange,
                                ),
                                Text("Expenses"),
                              ],
                            ),
                            Column(
                              children: [
                                Text("0"),
                                Divider(
                                  height: 1,
                                  color: Colors.deepOrange,
                                ),
                              ],
                            )
                          ],
                        ),
                        Divider(
                          height: 1,
                          color: Colors.deepOrange,
                        ),
                        Text("Total Credit = 0"),
                        Divider(
                          height: 1,
                          color: Colors.deepOrange,
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  elevation: 10,
                  child: Container(
                    height: 100,
                    width: mediaQuery.size.width * 0.47,
                    child: Column(
                      children: [
                        Text("Debit"),
                        Divider(
                          height: 1,
                          color: Colors.deepOrange,
                        ),
                        Row(
                          children: [
                            Column(
                              children: [
                                Text("Leave"),
                                Divider(
                                  height: 1,
                                  color: Colors.deepOrange,
                                ),
                                Text("Absent"),
                              ],
                            ),
                            Column(
                              children: [
                                Text("0"),
                                Divider(
                                  height: 1,
                                  color: Colors.deepOrange,
                                ),
                                Text("7143"),
                              ],
                            )
                          ],
                        ),
                        Divider(
                          height: 1,
                          color: Colors.deepOrange,
                        ),
                        Text("Total Deduct = 0"),
                        Divider(
                          height: 1,
                          color: Colors.deepOrange,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Text("Net Payable Salary : 0"),
          Card(
            elevation: 10,
            child: Container(
              height: 30,
              child: Row(
                children: [
                  Divider(
                    height: 1,
                    color: Colors.deepOrange,
                  ),
                  Text("Salary Month : 02-2021"),
                  Divider(
                    height: 1,
                    color: Colors.deepOrange,
                  ),
                  Text("Credit Date : 26-02-2021"),
                  Divider(
                    height: 1,
                    color: Colors.deepOrange,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}