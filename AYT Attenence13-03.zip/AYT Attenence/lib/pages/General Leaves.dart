import 'dart:convert';

import 'package:AYT_Attendence/API/api.dart';
import 'package:AYT_Attendence/model/GeneralLeaveModel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class GeneralLeave extends StatelessWidget{

  Future<GeneralLeaveModel> loadStudent() async {
    await wait(5);
    var endpointUrl = All_API().baseurl+All_API().api_general_leaves;
    Map<String, String> headers = {
      All_API().key: All_API().keyvalue,
    };
    var response = await http.get(endpointUrl,headers: headers);
    var jasonData = jsonDecode(response.body);
    print('General : '+jasonData.toString());
    return GeneralLeaveModel.fromJson(jasonData);
  }

  Future wait(int seconds) {
    return new Future.delayed(Duration(seconds: seconds), () => {});
  }

  @override
  Widget build(BuildContext context) {
    MediaQueryData mediaQuery = MediaQuery.of(context);
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Container(
          child: Text(
            'General Leave', style: TextStyle(color: Colors.blue[2000]),),
        ),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.blue[1000],
      ),
      body: Container(
        child: Row(
          children: [
            Container(
              width: mediaQuery.size.width * 0.50,
              child: Card(
                child: Column(
                  children: [
                    Text("Date",style: TextStyle(fontSize: 30,color: Colors.black),textAlign: TextAlign.center,),
                    Divider(
                      height: 1,
                      color: Colors.deepOrange,
                    ),
                    FutureBuilder<GeneralLeaveModel>(
                        future: loadStudent(),
                        builder: (context,snapshot){
                          if(snapshot.hasData){
                            return ListView.builder(
                                itemCount: snapshot.data.data.length,
                                scrollDirection: Axis.vertical,
                                shrinkWrap: true,
                                itemBuilder: (context, index){
                                  var article = snapshot.data.data[index];
                                  print("check--> "+article.name);
                                  var date = DateTime.parse(article.date);
                                  var formattedDate = "${date.day}-${date.month}-${date.year}";

                                  print (formattedDate);
                                  return Card(
                                    elevation: 10,
                                    child: Text(formattedDate,style: TextStyle(fontSize: 20,color: Colors.black,),textAlign: TextAlign.center,),
                                  );
                                }
                            );
                          }
                          else{
                            return Center(child: CircularProgressIndicator());
                          }
                        }
                    ),
                  ],
                ),
              ),
            ),
            Divider(
              height: 1,
              color: Colors.deepOrange,
            ),
            Container(
              width: mediaQuery.size.width * 0.50,
              child: Card(
                child: Column(
                  children: [
                    Text("Name",style: TextStyle(fontSize: 30,color: Colors.black),),
                    Divider(
                      height: 1,
                      color: Colors.deepOrange,
                    ),
                    FutureBuilder<GeneralLeaveModel>(
                      future: loadStudent(),
                      builder: (context,snapshot){
                        if(snapshot.hasData){
                          return ListView.builder(
                              itemCount: snapshot.data.data.length,
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              itemBuilder: (context, index){
                                var article = snapshot.data.data[index];
                                return Card(
                                  elevation: 10,
                                  child: Column(
                                      children: [
                                        Text(article.name,style: TextStyle(fontSize: 20,color: Colors.black,),textAlign: TextAlign.center,),
                                      ]),
                                );
                              }
                          );
                        }
                        else{
                          return Center(child: CircularProgressIndicator());
                        }
                      }
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}