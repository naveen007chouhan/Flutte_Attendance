import 'package:AYT_Attendence/Widgets/SizeConfig.dart';
import 'package:AYT_Attendence/pages/ScannerClass.dart';
import 'package:barcode_scan/barcode_scan.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class checkIN_OUT extends StatefulWidget{
  @override
  _checkIN_OUTState createState() => _checkIN_OUTState();
}

class _checkIN_OUTState extends State<checkIN_OUT> {

  String result = "Hey there !";
  String name;
  String date;
  String uniqID;
  String lat_long;
  String action;
  String address;
  String device;
  Future _scanQR() async {
    try {
      String qrResult = await BarcodeScanner.scan();
      setState(() {
        result = qrResult;
        print(result);
      });
    } on PlatformException catch (ex) {
      if (ex.code == BarcodeScanner.CameraAccessDenied) {
        setState(() {
          result = "Camera permission was denied";
          print(result);
        });
      } else {
        setState(() {
          result = "Unknown Error $ex";
          print(result);
        });
      }
    } on FormatException {
      setState(() {
        result = "You pressed the back button before scanning anything";
        print(result);
      });
    } catch (ex) {
      setState(() {
        result = "Unknown Error $ex";
        print(result);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Container(
      height: SizeConfig.safeBlockVertical * 100, //10 for example
      width: SizeConfig.safeBlockHorizontal * 100, //10 for example
      child: Row(
        children: [
          Container(
            height: 100,
            width: SizeConfig.blockSizeHorizontal*50,
            child: Card(
              elevation: 8,
              shadowColor: Colors.red,
              child: InkWell(
                onTap: (){
                  print("Check In Clicked");
                  //_scanQR();
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => ScannerClass()));
                },
                child: Row(
                  children: [
                    Container(
                        height: 100,
                        width: 60,
                        child: Image.asset('assets/chack_in.png',height: 40,width: 40,)
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          top: 20, left: 10, right: 0, bottom: 0),
                      child: Column(
                        children: [
                          Text('CHECK IN'),
                          Text("Time"),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
          Container(
            height: 100, //10 for example
            width: SizeConfig.blockSizeHorizontal*50, //10 for example
            child: Card(
              elevation: 8,
              shadowColor: Colors.red,
              child: InkWell(
                onTap: (){
                  print("Check Out Clicked");
                  _scanQR();
                },
                child: Row(
                  children: [
                    Container(
                        height: 100,
                        width: 60,
                        child: Image.asset('assets/check-out.png',height: 40,width: 40,)
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          top: 20, left: 10, right: 0, bottom: 0),
                      child: Column(
                        children: [
                          Text('CHECK OUT'),
                          Text("Time"),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}