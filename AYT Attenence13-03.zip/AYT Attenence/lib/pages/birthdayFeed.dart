import 'dart:convert';

import 'package:AYT_Attendence/API/api.dart';
import 'package:AYT_Attendence/model/BirthdayModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;

class birthdayFeed extends StatefulWidget{
  @override
  _birthdayFeedState createState() => _birthdayFeedState();
}

class _birthdayFeedState extends State<birthdayFeed> {

  Future<Birthdaymodel>newsdetail() async {
    var endpointUrl = All_API().baseurl + All_API().api_birthday;
    Map<String, String>  queryParameter={
      '':'',
    };
    String queryString = Uri(queryParameters: queryParameter).query;
    var requestUrl = endpointUrl + '?' + queryString;
    print(requestUrl);
    try {
      var response = await http.get(requestUrl,headers: {
        All_API().key: All_API().keyvalue,
      });
      if(response.statusCode==200){
        var jsonString = response.body;
        print("Birthday : "+jsonString);
        var jsonMap = json.decode(jsonString);
        return Birthdaymodel.fromJson(jsonMap);
      }
    }
    catch(Exception){
      return Exception;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Birthdaymodel>(
      future: newsdetail(),
      builder: (context,snapshot){
        if(snapshot.hasData){
          if(snapshot!=null){
            var path=All_API().baseurl+snapshot.data.path;
            return ListView.builder(
                itemCount: snapshot.data.data.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index){
                  var article = snapshot.data.data[index];
                  print(path+article.image);
                  return Card(
                      elevation: 10,
                      child: Column(
                        children: [
                          Container(
                            child: Image.network((path+article.image),height: 80,width: 80,),
                          ),
                          Container(
                            color:Colors.blue[2000],
                            width: 200,
                            height: 50,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.all(3.0),
                            child: Text(article.name,style: TextStyle(fontSize: 15,color: Colors.white),),
                          ),
                          Container(
                            color:Colors.blue[2000],
                            width: 200,
                            height: 50,
                            alignment: Alignment.center,
                            margin: const EdgeInsets.all(3.0),
                            child: Text(article.designation,style: TextStyle(fontSize: 15,color: Colors.white),),
                          ),
                        ],
                      )
                  );
                }
            );
          }
          else{
            return Visibility(
              child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index){
                    return Card(
                        elevation: 10,
                        child: Column(
                          children: [
                            Container(
                              child: Image.asset(("assets/ayt.png"),height: 80,width: 80,),
                            ),
                            Container(
                              color:Colors.blue[2000],
                              width: 200,
                              height: 50,
                              alignment: Alignment.center,
                              margin: const EdgeInsets.all(3.0),
                              child: Text("Adiyogi Technosoft",style: TextStyle(fontSize: 15,color: Colors.white),),
                            ),
                            Container(
                              color:Colors.blue[2000],
                              width: 200,
                              height: 50,
                              alignment: Alignment.center,
                              margin: const EdgeInsets.all(3.0),
                              child: Text("Adiyogi Technosoft",style: TextStyle(fontSize: 15,color: Colors.white),),
                            ),
                          ],
                        )
                    );
                  }
              ),
              visible: false,
            );
          }
        }
        else
          //return Center(child: CircularProgressIndicator());
          return ListView.builder(
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index){
                return Card(
                    elevation: 10,
                    child: Column(
                      children: [
                        Container(
                          child: Image.asset(("assets/ayt.png"),height: 80,width: 80,),
                        ),
                        Container(
                          color:Colors.blue[2000],
                          width: 200,
                          height: 50,
                          alignment: Alignment.center,
                          margin: const EdgeInsets.all(3.0),
                          child: Text("Adiyogi Technosoft",style: TextStyle(fontSize: 15,color: Colors.white),),
                        ),
                        Container(
                          color:Colors.blue[2000],
                          width: 200,
                          height: 50,
                          alignment: Alignment.center,
                          margin: const EdgeInsets.all(3.0),
                          child: Text("Adiyogi Technosoft",style: TextStyle(fontSize: 15,color: Colors.white),),
                        ),
                      ],
                    )
                );
              }
          );
      },
    );
  }
}