// ignore: camel_case_types
import 'dart:io';

class All_API {
  @override
  noSuchMethod(Invocation invocation) async{
    // TODO: implement noSuchMethod
    return super.noSuchMethod(invocation);
  }


  final key = 'X-API-KEY';
  final keyvalue = 'NODN2D0I7W4V8I2K';
  final FcmId ="NODN2D0I7W4V8I2K";
  final employee_ID="";
  final uniq_ID="";
  final slider_img_path ="uploads/slider/";
  final employee_expense_img_path ="/uploads/employee_expense/";
  final news_img_path ="/uploads/news/";

  String baseurl="http://adiyogitechnosoft.com/attendance_dev/api/";
  String baseurl_img="http://adiyogitechnosoft.com/attendance_dev/";


  String api_login= "/employee/employee_login";

  // ignore: non_constant_identifier_names
  String api_otp_verify="employee/verify_otp";

  // ignore: non_constant_identifier_names
  String api_news="news";

  // ignore: non_constant_identifier_names
  String api_birthday="employee/birthday";

  // ignore: non_constant_identifier_names
  String api_leave_type="leave/leaves_date_type/";

  // ignore: non_constant_identifier_names
  String api_slider="slider";

  // ignore: non_constant_identifier_names
  String api_track_attendance="employee/attandance_report/";

  // ignore: non_constant_identifier_names
  String api_department="department/";

  // ignore: non_constant_identifier_names
  String api_designation="designation/";

  // ignore: non_constant_identifier_names
  String api_general_leaves="general_leave";

  // ignore: non_constant_identifier_names
  String api_profile="employee/profile_image/";

  // ignore: non_constant_identifier_names
  String api_apply_leave="leave";

  // ignore: non_constant_identifier_names
  String api_leave_spinner="leave/leaves_date_type/";

  // ignore: non_constant_identifier_names
  String api_about_us="settings/";

  // ignore: non_constant_identifier_names
  String api_privacy_policy="settings/";

  // ignore: non_constant_identifier_names
  String api_tearm_condition="settings/";

  // ignore: non_constant_identifier_names
  String api_contact_us_="settings/";

  // ignore: non_constant_identifier_names
  String api_notification ="notification/";

  // ignore: non_constant_identifier_names
  String api_salary_list="salary/";

  // ignore: non_constant_identifier_names
  String api_salary_detail="salary/salary_all_detail/";

  // ignore: non_constant_identifier_names
  String api_type_expense_list="expense";

// ignore: non_constant_identifier_names
  String api_expense_list="employee_expense/";

// ignore: non_constant_identifier_names
  String api_upload_expense="employee_expense";

  // ignore: non_constant_identifier_names
  String api_update_expense="employee_expense/employee_expense_update";
}